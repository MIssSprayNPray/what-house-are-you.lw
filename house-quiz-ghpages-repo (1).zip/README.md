# House Quiz on GitHub Pages

This repo contains a single-page interactive quiz: **"Which House Do You Belong To?"**

## How to publish on GitHub Pages

1. Create a new repository on GitHub.
2. Upload all files from this folder to the root of that repo and commit.
3. Go to **Settings → Pages** in your GitHub repo.
4. Under **Source**, select "Deploy from a branch", pick your default branch (usually `main`) and set the folder to **/(root)**.
5. Click Save.
6. Your quiz will be live at:

   ```
   https://<your-username>.github.io/<repo-name>/
   ```

That's it!
